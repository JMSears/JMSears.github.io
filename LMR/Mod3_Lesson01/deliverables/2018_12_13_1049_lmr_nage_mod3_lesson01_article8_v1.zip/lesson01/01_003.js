var primaryArticle = 8;

var relatedArticles = [5,37];

var lawsAndRegs = []

var policies = [];