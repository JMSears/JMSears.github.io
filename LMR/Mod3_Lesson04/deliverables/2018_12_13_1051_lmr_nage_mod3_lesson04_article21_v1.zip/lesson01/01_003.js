var primaryArticle = 21;

var relatedArticles = [13,23];

var lawsAndRegs = ["5 USC Chapter 71 (the Statute)"]

var policies = [];