var primaryArticle = 15;

var relatedArticles = [13,17,40,60];

var lawsAndRegs = [
"5 USC 6101",
"5 USC 6103",
"5 USC 6120",
"5 USC 6121(3)",
"5 USC 6122",
"5 USC 6122(a)(2)",
"5 USC 6126",
"5 USC 6131",
"5 USC 6131(c)(3)(C)",
"5 USC 7106(b)(1)",
"38 USC 7401 (1)",
"38 USC 7422",
"38 USC 7453 (h)",
"38 USC 7454",
"38 USC 7454(b)",
"38 USC 7457",
"38 USC 7457(c)",
"5 CFR 550.141",
"5 CFR 610.121(b)",
"5 CFR 610.404",
"5 CFR 610.406",
"5 CFR Part 610"
];

var policies = [
"VA Form 5283",
"VA Handbook 5001",
"VA Handbook 5007, Part V, Chapter 5, Paragraph 1",
"VA Handbook 5011"
];