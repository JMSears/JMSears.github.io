var primaryArticle = 20;

var relatedArticles = [];

var lawsAndRegs = []

var policies = [];