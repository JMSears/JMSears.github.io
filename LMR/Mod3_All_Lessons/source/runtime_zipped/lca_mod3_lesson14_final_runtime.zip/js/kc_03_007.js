// JavaScript Document

/* **************************************************** */
/*                     N O T I C E                      */
/* **************************************************** */
/*                                                      */
/*            @author Instructus Media, Ltd.            */
/*              @copyright Copyright ©2018              */
/*     Instructus Media, Ltd., All rights reserved.     */
/*               info@instructusmedia.com               */
/*                                                      */
/*   Reuse of this code or any part of this interface   */
/*       other than to develop courseware for the       */
/*    United States Department of Veterans Affairs      */
/*               is strictly prohibited.                */
/*         Use permitted under special license.         */
/*  See the License.txt file for license information.   */
/*               This block must remain.                */
/*                                                      */
/*            Version 1.1.2.11  -  8/2/2018            */
/*                                                      */
/* **************************************************** */


var assessment_type = "practice";	// assessment_type = "practice" "eol" "eoc" "survey"
var start_question_at = 1;	// enter 1 for normal use or any other numeric value to start question count at
var results_to_show = "questions, options, indicators, inputs, feedback" // "summary, questions, options, indicators, inputs, feedback";
//var results_to_show = "indicators, inputs, feedback" // "summary, questions, options, indicators, inputs, feedback";
var allow_retake = false;	// this will allow the user to retake the assessment if they do not pass
var required_score =  0;	// this number represents the required score as a percentage (80%)
var questions_to_pull = 1;	// total number of question to use from total bank
var questions_displayed_per_page = 1;	// questions to display per page
var randomize_questions = false;	// randomize (true or false), this make questions appear in a random order
var process_code = true;	// do you want to run additional code after the questions are submitted (true or false)
var msgSelectionRequired = "Please select or enter an answer for each question before continuing.";

if (assessment_type == "practice") {
    var pageHeading = '<p id="instructionsExam"><p><strong>Instructions:</strong> Read the following questions and select the best answer(s) for each, then submit your responses to see how you scored.</p></p>';
    var msgPass = "After reviewing your results, please select Next to continue.";
    var msgFail = "You may <a href=\"#\" onclick=\"reloadPage();return false;\"><strong>retake the assessment</strong></a> after reviewing your results.";
}
if (assessment_type == "eol") {
    var pageHeading = '<p id="instructionsExam"><p><strong>Instructions:</strong> Read the following question, select the best answer(s) then select the Submit button. Once you have answered all questions a summary report will display with your score.</p></p>';
    var msgPass = "After reviewing your results, please select Next to continue.";
    var msgFail = "You may <a href=\"#\" onclick=\"reloadPage();return false;\"><strong>retake the assessment</strong></a> after reviewing your results.";
}
if (assessment_type == "eoc") {
    var pageHeading = '<p id="instructionsExam"><p><strong>Instructions:</strong> Read the following question, select the best answer(s) then select the Submit button. Once you have answered all questions a summary report will display with your score.</p></p>';
    var msgPass = "After reviewing your results, please select Next to view the End of Course Instructions.";
    var msgFail = "You may <a href=\"#\" onclick=\"reloadPage();return false;\"><strong>retake the exam</strong></a> after reviewing your results.";
}

/******** QUESTIONS *********/
var question = new Array();
	
// Multiple Choice (Radio Buttons)
	question[1] = {
	questionGUID: "e15e181e-2604-4b89-b1c8-41e5008f7dd6",
	type: "multiple_choice",	// type: "multiple_choice", "multiple_select", "matching", "free_text"
	question: "<p>Steven&rsquo;s Supervisor asks him to explain what he witnessed. Steven was not involved in the argument between the two Employees. He has no reasonable belief that his eyewitness account will result in discipline against him.</p><p>Is Steven entitled to Union representation?</p>",
	items:[
					{ items: "Yes" },
					{ items: "No" }
				],

		answer: "b",	// answer: "b",

		feedback: [
					{
						correct: "<p>Yes, that is correct. Option B is true because Steven does not have a reasonable belief that his eyewitness account will result in discipline against him.</p>",
						incorrect: "<p>That is incorrect. Option B is true because Steven does not have a reasonable belief that his eyewitness account will result in discipline against him.</p>",
						feedbacka: "" // define feedback for each survey option or use feedbacka only for single feedback
					}
				]
	};
/********************** DO NOT REMOVE **********************/
document.write("<script type='text/javascript' src='"+path+"_template/js/questions.js'></script>");
function code_onLoad() {	// code that will be process when page is loaded
	if(assessment_type=="practice") { document.getElementById('wrapperContent').className="knowledgeCheck" }
	document.getElementById('msgPageInstructions').innerHTML="Select a response for each question then Submit to continue."
}
function code_onSubmit() {	// code that will be process at end of course
	document.getElementById('msgPageInstructions').innerHTML="Minimum passing score was not achieved. Select Reset Assessment to try again."
		if (total_score >= required_score) {
			enableNext();
		document.getElementById('msgPageInstructions').innerHTML="Great job! Select Next to continue."
		}
}
/********************** DO NOT REMOVE **********************/
