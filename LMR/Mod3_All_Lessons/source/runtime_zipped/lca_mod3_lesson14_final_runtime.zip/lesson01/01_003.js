var primaryArticle = 36;

var relatedArticles = [6,7,15,16];

var lawsAndRegs = ["5 USC 552a(e)(5)","5 USC 7114(a)(2)(B)","5 USC 7114(b)","38 USC 5705","38 CFR 0.735-12(b)"]

var policies = ["VA Directive 0700, VA Handbook 0700","VHA Directive 2008-077","VA Directive 0730, VA Handbook 0730"];