var primaryArticle = 27;

var relatedArticles = [6,22,25];

var lawsAndRegs = ["5 USC 7201","5 CFR Part 720"]

var policies = [];