var primaryArticle = 26;

var relatedArticles = [13,25,62];

var lawsAndRegs = ["Back Pay Act of 1966","5 USC Chapter 71 (the Statute)","5 USC 5596","Veteran Employment Opportunities Act of 1998","Title 5 CFR","5 CFR Part 335","5 CFR 335.104","5 CFR 213.3402","5 CFR 362 Subpart B","5 CFR 315.604","5 CFR 315.707","5 CFR 213","5 CFR 307","5 CFR 213.3102(u)","5 CFR Part 330 Subparts F and G"]

var policies = [];