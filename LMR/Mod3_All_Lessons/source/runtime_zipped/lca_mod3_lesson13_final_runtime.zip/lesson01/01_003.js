var primaryArticle = 35;

var relatedArticles = [];

var lawsAndRegs = []

var policies = [];