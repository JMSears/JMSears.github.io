var primaryArticle = 48;

var relatedArticles = [13,22];

var lawsAndRegs = []

var policies = [];