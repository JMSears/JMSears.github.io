var primaryArticle = 49;

var relatedArticles = [13];

var lawsAndRegs = []

var policies = [];