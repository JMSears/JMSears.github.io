var primaryArticle = 40;

var relatedArticles = [6,39,41];

var lawsAndRegs = ["5 USC 7103(a)(9)","5 USC 7121(c)","38 USC 7401(3)","38 USC 7405(a)(1)(B)","38 USC 7422","38 USC 7422(e)","5 USC 7121","5 USC 4303","5 USC 7512","5 USC 2302(b)(1)","5 USC Chapter 71 (the Statute)","Title 5 Chapter 73, Subchapter III","5 USC 7532"]

var policies = ["VA Handbook 5021, Part 3, Ch. 3","VA Directive 5005","VA Handbook 5005"];