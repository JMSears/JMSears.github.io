var primaryArticle = 38;

var relatedArticles = [6,40];

var lawsAndRegs = ["Privacy Act","5 USC 522a","5 USC 7114 (b)(4)","Federal Records Act","Health Insurance Portability and Accountability Act (HIPAA)"]

var policies = [];