var primaryArticle = 22;

var relatedArticles = [13,24,40];

var lawsAndRegs = ["38 USC 714","38 USC 7401(1) and (3)","USC 7405(a)(1)(A) and (B)","5 USC 4301","5 USC Chapter 43","5 USC 4303","5 USC 7513","5 CFR, Part 430","5 CFR Part 451","5 CFR 451.104","5 CFR 430.203","5 CFR 430.208(d)","5 CFR 531.404(a)(1)","5 CFR 430.208","5 CFR Part 430.101","5 CFR Part 430.102","5 CFR Part 430.201","5 CFR Part 432","5 CFR 430.208(g)", "5 CFR Part 732"]

var policies = ["VA Handbook 5013"];