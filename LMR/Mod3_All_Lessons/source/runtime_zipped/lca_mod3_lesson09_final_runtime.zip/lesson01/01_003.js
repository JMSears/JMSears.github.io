var primaryArticle = 28;

var relatedArticles = [22];

var lawsAndRegs = ["38 USC 7401(3)", "38 USC 7405(a)(1)(B)","5 USC 5335","5 USC 3321(a)(2)","38 USC 7422","38 USC 7401(1)","5 CFR part 531","5 CFR 531.414(c)","5 CFR 531.409(d)"]

var policies = ["VA Handbook 5007, VA Handbook 5007 Part III, Chapter 5"];