var primaryArticle = 23;

var relatedArticles = [13,19,40];

var lawsAndRegs = ["5 USC 4103(a)","5 USC 4109","The Statute (5 USC Chapter 71)","5 CFR part 410","5 CFR 410.306","5 CFR 410.307 (b)"]

var policies = ["VA Directive and Handbook 5015", "VHA Directive 1018"];