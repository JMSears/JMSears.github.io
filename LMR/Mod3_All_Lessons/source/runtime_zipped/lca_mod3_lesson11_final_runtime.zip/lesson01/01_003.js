var primaryArticle = 24;

var relatedArticles = [40];

var lawsAndRegs = ["5 USC Chapter 45","38 USC 7401(3)","5 CFR Part 451","5 CFR 451.103","5 CFR 451.103(b)","5 CFR 451.103(c)(1)","5 CFR 451.103(c)(2)","5 CFR 430.203"]

var policies = ["VA Directive 5017","VA Handbook 5017"];