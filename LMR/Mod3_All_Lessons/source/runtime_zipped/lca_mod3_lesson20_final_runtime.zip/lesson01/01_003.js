var primaryArticle = 39;

var relatedArticles = [13,23];

var lawsAndRegs = ["The Administrative Resolution Act (ADRA)","5 USC 574 (ADRA)","5 USC 552a (Privacy Act)","29 CFR 1614.102(b)(2)"]

var policies = ["VA Directive 5978","VA Handbook 5978.2"];