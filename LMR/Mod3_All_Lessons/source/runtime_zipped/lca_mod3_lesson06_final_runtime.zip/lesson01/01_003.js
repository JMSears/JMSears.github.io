var primaryArticle = 25;

var relatedArticles = [13,17,26,60,66,69];

var lawsAndRegs = ["5 USC 7106","38 USC 7422(b)","5 USC 7106(a)(2)","38 USC 7422","5 CFR Part 335, Subpart (a)"]

var policies = ["VA Handbook 5005, Part III, Ch. 4, Section 8"];