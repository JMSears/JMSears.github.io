var primaryArticle = 37;

var relatedArticles = [7,36];

var lawsAndRegs = ["5 USC 7106(a)(2)(A)","38 USC 714","38 USC 7401(3)","38 USC 7422","5 CFR Part 293"]

var policies = ["VA Handbook 5021"];