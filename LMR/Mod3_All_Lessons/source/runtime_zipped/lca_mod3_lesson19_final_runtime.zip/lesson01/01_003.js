var primaryArticle = 41;

var relatedArticles = [40];

var lawsAndRegs = ["5 USC Chapter 71 (the Statute)","5 USC 5596"]

var policies = [];