var primaryArticle = 29;

var relatedArticles = [13,15,61];

var lawsAndRegs = ["38 USC 7403","38 USC 7405"]

var policies = ["VA Handbook 5005, Part II, Chapter 3, Section G","VA Handbook 5005, Part II, Chapter 3, Section F, paragraph 3"];